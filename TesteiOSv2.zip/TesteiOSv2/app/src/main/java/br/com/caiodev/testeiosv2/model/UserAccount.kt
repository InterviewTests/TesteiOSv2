package br.com.caiodev.testeiosv2.model

class UserAccount {

    val agency = ""
    val balance = 0.0
    val bankAccount = ""
    val name = ""
    val userId = 0
}