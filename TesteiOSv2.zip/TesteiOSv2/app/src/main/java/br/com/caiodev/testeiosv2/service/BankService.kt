package br.com.caiodev.testeiosv2.service

import br.com.caiodev.testeiosv2.model.LoginRequest
import br.com.caiodev.testeiosv2.model.LoginResponse
import br.com.caiodev.testeiosv2.model.UserAccountDetail
import kotlinx.coroutines.Deferred
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST

interface BankService {

    @POST("login")
    fun login(@Body request: LoginRequest): Deferred<LoginResponse>

    @GET("statements/1")
    fun getUserDetails(): Deferred<UserAccountDetail>
}