package br.com.caiodev.testeiosv2.model

data class LoginRequest(val user: String, val password: String)