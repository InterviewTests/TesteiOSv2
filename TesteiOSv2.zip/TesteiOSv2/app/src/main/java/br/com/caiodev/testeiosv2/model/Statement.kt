package br.com.caiodev.testeiosv2.model

class Statement {

    val date = ""
    val desc = ""
    val title = ""
    val value = 0.0
}