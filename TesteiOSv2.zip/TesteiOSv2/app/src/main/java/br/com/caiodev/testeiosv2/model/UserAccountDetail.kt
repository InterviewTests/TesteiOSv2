package br.com.caiodev.testeiosv2.model

class UserAccountDetail {

    val error: Error? = null
    val statementList: MutableList<Statement>? = null
}