package br.com.caiodev.testeiosv2.model

class LoginResponse {

    val userAccount: UserAccount? = null
    val error: Error? = null
}