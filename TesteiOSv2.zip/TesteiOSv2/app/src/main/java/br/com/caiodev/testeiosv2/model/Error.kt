package br.com.caiodev.testeiosv2.model

class Error {

}