//
//  protocolLoginTableViewCellDelegate .swift
//  BankTesteiOSv2
//
//  Created by LeandroLee on 25/03/21.
//

import Foundation

protocol LoginTableViewCellDelegate
{
      func loginTableViewCellAction()
}
